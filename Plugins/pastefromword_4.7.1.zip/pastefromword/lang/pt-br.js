/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'pt-br', {
	confirmCleanup: 'O texto que você deseja colar parece ter sido copiado do Word. Você gostaria de remover a formatação antes de colar?',
	error: 'Não foi possível limpar os dados colados devido a um erro interno',
	title: 'Colar do Word',
	toolbar: 'Colar do Word'
} );
