/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'et', {
	confirmCleanup: 'Tekst, mida tahad asetada näib pärinevat Wordist. Kas tahad selle enne asetamist puhastada?',
	error: 'Asetatud andmete puhastamine ei olnud sisemise vea tõttu võimalik',
	title: 'Asetamine Wordist',
	toolbar: 'Asetamine Wordist'
} );
