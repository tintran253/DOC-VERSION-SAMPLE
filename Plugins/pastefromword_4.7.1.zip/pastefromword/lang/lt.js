/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'lt', {
	confirmCleanup: 'Tekstas, kurį įkeliate yra kopijuojamas iš Word. Ar norite jį išvalyti prieš įkeliant?',
	error: 'Dėl vidinių sutrikimų, nepavyko išvalyti įkeliamo teksto',
	title: 'Įdėti iš Word',
	toolbar: 'Įdėti iš Word'
} );
