/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'hr', {
	confirmCleanup: 'Tekst koji želite zalijepiti čini se da je kopiran iz Worda. Želite li prije očistiti tekst?',
	error: 'Nije moguće očistiti podatke za ljepljenje zbog interne greške',
	title: 'Zalijepi iz Worda',
	toolbar: 'Zalijepi iz Worda'
} );
